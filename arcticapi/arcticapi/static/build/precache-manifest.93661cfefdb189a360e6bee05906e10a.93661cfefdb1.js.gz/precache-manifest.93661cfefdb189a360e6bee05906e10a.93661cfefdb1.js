self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "236cf5f767b745a978d8be7594fd237e",
    "url": "/static/build/index.html"
  },
  {
    "revision": "ad49a58a19e159921dd9",
    "url": "/static/build/static/css/main.81fea899.chunk.css"
  },
  {
    "revision": "8d8c08d51c5335ef4d62",
    "url": "/static/build/static/js/2.3e7f1c5a.chunk.js"
  },
  {
    "revision": "86f96943d6537349861c4002a14026e3",
    "url": "/static/build/static/js/2.3e7f1c5a.chunk.js.LICENSE"
  },
  {
    "revision": "ad49a58a19e159921dd9",
    "url": "/static/build/static/js/main.20de96c9.chunk.js"
  },
  {
    "revision": "c2f1959068e82596c05d",
    "url": "/static/build/static/js/runtime-main.19417555.js"
  }
]);